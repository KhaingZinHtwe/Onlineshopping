package com.example.villageapp.model;

public class VillageInfo {
    String vName;
    double vArea;
    double vHomeCount;
    double vPopulation;
    double vMale;
    double vFemale;

    public VillageInfo(String vName) {
        this.vName = vName;
    }

    public String getvName() {
        return vName;
    }

    public void setvName(String vName) {
        this.vName = vName;
    }

    public double getvArea() {
        return vArea;
    }

    public void setvArea(double vArea) {
        this.vArea = vArea;
    }

    public double getvHomeCount() {
        return vHomeCount;
    }

    public void setvHomeCount(double vHomeCount) {
        this.vHomeCount = vHomeCount;
    }

    public double getvPopulation() {
        return vPopulation;
    }

    public void setvPopulation(double vPopulation) {
        this.vPopulation = vPopulation;
    }

    public double getvMale() {
        return vMale;
    }

    public void setvMale(double vMale) {
        this.vMale = vMale;
    }

    public double getvFemale() {
        return vFemale;
    }

    public void setvFemale(double vFemale) {
        this.vFemale = vFemale;
    }

    public VillageInfo(String vName, double vArea, double vHomeCount, double vPopulation, double vMale, double vFemale) {
        this.vName = vName;
        this.vArea = vArea;
        this.vHomeCount = vHomeCount;
        this.vPopulation = vPopulation;
        this.vMale = vMale;
        this.vFemale = vFemale;
    }
}
