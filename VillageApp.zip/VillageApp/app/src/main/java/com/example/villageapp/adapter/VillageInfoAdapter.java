package com.example.villageapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.villageapp.R;
import com.example.villageapp.model.VillageInfo;

import java.util.List;

public class VillageInfoAdapter extends RecyclerView.Adapter<VillageInfoAdapter.VillageInfoViewHolder> {
    List<VillageInfo> villageInfoList;
    Context mContext;
    public VillageInfoAdapter(Context mContext,List<VillageInfo> villageInfoList){
        this.villageInfoList=villageInfoList;
        this.mContext=mContext;
    }
    @NonNull
    @Override
    public VillageInfoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View villageInfoView= LayoutInflater.from(parent.getContext()).inflate(R.layout.city_item,parent,false);
        return new VillageInfoViewHolder(villageInfoView);
    }

    @Override
    public void onBindViewHolder(@NonNull VillageInfoAdapter.VillageInfoViewHolder holder, int position) {
        holder.vName.setText(villageInfoList.get(position).getvName());
//        holder.vHomeCount.setText((int) villageInfoList.get(position).getvHomeCount());
//        holder.vArea.setText((int) villageInfoList.get(position).getvArea());
//        holder.vPopulation.setText((int) villageInfoList.get(position).getvPopulation());
//        holder.vFemale.setText((int) villageInfoList.get(position).getvFemale());
//        holder.vMale.setText((int) villageInfoList.get(position).getvMale());
    }

    @Override
    public int getItemCount() {
        return villageInfoList.size();
    }

    public class VillageInfoViewHolder extends RecyclerView.ViewHolder {
        TextView vName,vPopulation,vFemale,vMale,vHomeCount,vArea;
        public VillageInfoViewHolder(@NonNull View itemView) {
            super(itemView);
              vName=itemView.findViewById(R.id.txt_name);
//            vPopulation=itemView.findViewById(R.id.txt_population);
//            vHomeCount=itemView.findViewById(R.id.txt_hcount);
//            vArea=itemView.findViewById(R.id.txt_area);
//            vFemale=itemView.findViewById(R.id.txt_female);
//            vMale=itemView.findViewById(R.id.txt_male);
        }
    }
}
